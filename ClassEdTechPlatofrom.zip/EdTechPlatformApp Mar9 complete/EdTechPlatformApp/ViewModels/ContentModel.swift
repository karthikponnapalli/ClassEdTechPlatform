//
//  ContentModel.swift
//  EdTechPlatformApp
//
//  Created by Karthik Ponnapalli on 2/27/23.
//

import Foundation

class ContentModel:ObservableObject {
    //List of modules
    @Published var modules = [Module]()
    
    //current module
    @Published var currentModule:Module?
    var currentModuleIndex = 0
    
    init(){
    //get local json data
        getLocalData()
    }//end of init
    
    // Data Methods
    func getLocalData(){
        //get url of the json file
        let jsonUrl = Bundle.main.url(forResource: "data", withExtension: "json")
        
        //read the file into the dataobject
        do{
            let jsonData = try Data(contentsOf: jsonUrl!)
            
            //decode jsonData into Module array
            let jsonDecoder = JSONDecoder()
            let modules = try jsonDecoder.decode([Module].self, from: jsonData)
            
            //assign modules to modules property
            self.modules = modules
            
        }//end of do
        catch{
            print("json parse failed")
        }//endo fo catch
        
        
    }//end of getLocalData
    
    //Module Navigation Methods
    func beginModule(_ moduleid: Int){
        //find index for this module id
        for index in 0..<modules.count{
            if modules[index].id == moduleid{
                //found the matching module
                currentModuleIndex = index
                break
            }//end of if
        }//end of for
        
        //set current module
        currentModule = modules[currentModuleIndex]
        
    }//end of beginModule
}//end of class
